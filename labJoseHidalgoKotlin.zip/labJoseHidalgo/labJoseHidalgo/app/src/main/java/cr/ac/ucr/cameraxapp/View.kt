package cr.ac.ucr.cameraxapp

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView


class View : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visualizar_foto)
        /*
       val imageView: ImageView = findViewById(R.id.im)
        val intent:Bundle? = intent.extras
        val myuri:Uri = Uri.parse(intent?.getString("imageUri"))
        //println(myuri)
        imageView.setImageURI(myuri)*/

    }
}

package cr.ac.ucr.cameraxapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_pantalla_formulario.*

class Form : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla_formulario)
        click_botonEnviarInfo()
        click_botonEnviarFoto()
    }

    fun click_botonEnviarInfo(){
        enviarInfoBtn.setOnClickListener(){

            val destino = "testCovid19@gmail.com"
            val subject = nametv.getText().toString()
            
            var message = "Sintomas: "
            if(switchFiebre.isChecked()) {
                message = message + "Fiebre, "
            }
            if(switchTos.isChecked()) {
                message = message + "Tos, "
            }
            if(switchMigrana.isChecked()) {
                message = message + "Migraña, "
            }
            if(switchCansancio.isChecked()) {
                message = message + "Cansancio, "
            }
            if(switchOlfato.isChecked()) {
                message = message + "Perdida del olfato, "
            }
            if(switchGusto.isChecked()) {
                message = message + " Perdida del gusto "
            }

            val intent = Intent(Intent.ACTION_SEND)
            val addressees = arrayOf(destino)
            intent.putExtra(Intent.EXTRA_EMAIL, addressees)
            intent.putExtra(Intent.EXTRA_SUBJECT, subject)
            intent.putExtra(Intent.EXTRA_TEXT, message)
            intent.setType("message/rfc822")
            startActivity(Intent.createChooser(intent, "Enviar correo mediante:"));

            Toast.makeText(applicationContext, "Abriendo correo", Toast.LENGTH_SHORT).show()
        }
        }

    fun click_botonEnviarFoto(){
        enviarFotoBtn.setOnClickListener(){
               val ventanaFoto: Intent = Intent(applicationContext, MainActivity::class.java) //le asignamos la activity
              startActivity(ventanaFoto)
            Toast.makeText(applicationContext, "Cargando Camara", Toast.LENGTH_SHORT).show()
        }
    }
}
